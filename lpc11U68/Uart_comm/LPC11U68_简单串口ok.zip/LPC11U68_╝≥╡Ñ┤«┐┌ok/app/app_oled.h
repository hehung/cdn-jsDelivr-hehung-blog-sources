
#ifndef _APP_OLED_H_
#define _APP_OLED_H_

#include "stdint.h"

extern void OLED_Init(void);// -- OLED屏初始化程序，此函数应在操作屏幕之前最先调用

extern void OLED_Fill(unsigned char x1,unsigned char y1,unsigned char x2,unsigned char y2,unsigned char dot);
extern void OLED_Clear(void);

extern void OLED_Refresh_Gram(void);		   
extern void OLED_DrawPoint(unsigned char x,unsigned char y,unsigned char t);
extern void OLED_ShowHz(unsigned char x,unsigned char y,unsigned char chr,unsigned char mode);
extern void OLED_ShowChar(unsigned char x,unsigned char y,unsigned char chr,unsigned char size,unsigned char mode);
extern void OLED_ShowNum(unsigned char x,unsigned char y,unsigned int num,unsigned char len,unsigned char size);
extern void OLED_ShowString(unsigned char x,unsigned char y,const unsigned char *p,unsigned char size);	
extern void OLED_Hz_String(unsigned char x,unsigned char y,unsigned char chr_S,unsigned char chr_E);

#endif
