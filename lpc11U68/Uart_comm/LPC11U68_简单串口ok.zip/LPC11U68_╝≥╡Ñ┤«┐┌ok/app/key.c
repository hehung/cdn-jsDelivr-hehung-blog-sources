#include "key.h"

//获取开关1的状态
unsigned char Get_SW1_State(void)
{
	return Chip_GPIO_GetPinState(LPC_GPIO, BLINK_SWITCH_PORT, BLINK_SWITCH_BIT);
}

//获取开关2的状态
unsigned char Get_SW2_State(void)
{
	return Chip_GPIO_GetPinState(LPC_GPIO, CYCLE_SWITCH_PORT, CYCLE_SWITCH_BIT);
}

