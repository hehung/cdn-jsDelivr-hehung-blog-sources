#ifndef __UART_H__
#define __UART_H__

/* Ring buffer size */
#define UART_RB_SIZE 64

/* Set the default UART, IRQ number, and IRQ handler name */
#define LPC_USART       LPC_USART4
#define LPC_IRQNUM      USART1_4_IRQn
#define LPC_UARTHNDLR   USART1_4_IRQHandler

/* Default baudrate for testing */
#define UART_TEST_DEFAULT_BAUDRATE 115200

void Uart_Init(void);

#endif
