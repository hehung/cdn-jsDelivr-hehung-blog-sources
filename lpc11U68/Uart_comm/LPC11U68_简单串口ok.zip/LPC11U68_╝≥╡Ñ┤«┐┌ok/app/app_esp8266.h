#ifndef _APP_ESP8266_H_
#define _APP_ESP8266_H_


extern void ESP_Send_Data(char *data);
extern void ESP_Test(void);
extern void ESP_RST(void);
extern void ESP_CWMODE(unsigned char mode);
extern void ESP_CWJAP(char *name,char *pwd);
extern void ESP_CIPSTART(char *ip,int port);
extern void ESP_SEND(char *text);
extern unsigned char ESP_Return(void);
extern void ESP_Init(void);

#endif

