#ifndef __MYIIC_H
#define __MYIIC_H
#include "fsl_gpio.h"
#include "pin_mux.h"
 
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
 
//gpio_pin_config_t config={kGPIO_DigitalOutput,0};//输出配置
//gpio_pin_config_t config_input={kGPIO_DigitalInput}; //输入配置 
////IO方向设置
//#define SDA_IN()  GPIO_PinInit(GPIO,BOARD_INITPINS_GPIO_SCL_PORT,BOARD_INITPINS_GPIO_SCL_GPIO_PIN,&config_input)//配置为输入
//#define SDA_OUT() GPIO_PinInit(GPIO,BOARD_INITPINS_GPIO_SCL_PORT,BOARD_INITPINS_GPIO_SCL_GPIO_PIN,&config)//配置为输出

//IO操作函数	 
#define SET_IIC_SCL() GPIO_WritePinOutput(GPIO,BOARD_INITPINS_GPIO_SCL_PORT,BOARD_INITPINS_GPIO_SCL_GPIO_PIN,1)//输出1
#define CLR_IIC_SCL() GPIO_WritePinOutput(GPIO,BOARD_INITPINS_GPIO_SCL_PORT,BOARD_INITPINS_GPIO_SCL_GPIO_PIN,0)//输出0

#define SET_IIC_SDA() GPIO_WritePinOutput(GPIO,BOARD_INITPINS_GPIO_SDA_PORT,BOARD_INITPINS_GPIO_SDA_GPIO_PIN,1)//输出1
#define CLR_IIC_SDA() GPIO_WritePinOutput(GPIO,BOARD_INITPINS_GPIO_SDA_PORT,BOARD_INITPINS_GPIO_SDA_GPIO_PIN,0)//输出0
//#define IIC_SCL    PCout(0) //SCL
//#define IIC_SDA    PCout(1) //SDA	 
#define READ_SDA   GPIO_ReadPinInput(GPIO,BOARD_INITPINS_GPIO_SDA_PORT,BOARD_INITPINS_GPIO_SDA_GPIO_PIN)  //输入SDA 
    
//IIC所有操作函数
void IIC_Init(void);                //初始化IIC的IO口				 
void IIC_Start(void);				//发送IIC开始信号
void IIC_Stop(void);	  			//发送IIC停止信号
void IIC_Send_Byte(unsigned char txd);			//IIC发送一个字节
unsigned char IIC_Read_Byte(unsigned char ack);//IIC读取一个字节
unsigned char IIC_Wait_Ack(void); 				//IIC等待ACK信号
void IIC_Ack(void);					//IIC发送ACK信号
void IIC_NAck(void);				//IIC不发送ACK信号

void IIC_Write_One_Byte(unsigned char daddr,unsigned char addr,unsigned char data);
unsigned char IIC_Read_One_Byte(unsigned char daddr,unsigned char addr);	  

unsigned char PCF8591_ReDat(void);
void PCF8591_WrDat(unsigned char c);


#endif
















