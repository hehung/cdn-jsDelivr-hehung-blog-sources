#include "delay.h"

void Delay_us(uint32_t us)
{
	uint32_t i,j;
	for(i=0;i<us;i++)
	{
		for(j=0;j<8;j++)
		{
			__asm("nop");
		}
	}
}

void Delay_ms(uint32_t ms)
{
	uint32_t i,j;
	for(i=0;i<ms;i++)
	{
		for(j=0;j<765;j++)
		{
			Delay_us(1);
		}
	}
}
