#ifndef __MYOS_H__
#define __MYOS_H__

extern void Timer_Task_2ms(void);
extern void Timer_Task_50ms(void);
extern void Timer_Task_500ms(void);
extern void Timer_Task_1s(void);

#endif
