#include "myiic.h"
#include "delay.h"

gpio_pin_config_t config={kGPIO_DigitalOutput,0};//输出配置
gpio_pin_config_t config_input={kGPIO_DigitalInput}; //输入配置 
//IO方向设置
#define SDA_IN()  GPIO_PinInit(GPIO,BOARD_INITPINS_GPIO_SDA_PORT,BOARD_INITPINS_GPIO_SDA_GPIO_PIN,&config_input)//配置为输入
#define SDA_OUT() GPIO_PinInit(GPIO,BOARD_INITPINS_GPIO_SDA_PORT,BOARD_INITPINS_GPIO_SDA_GPIO_PIN,&config)//配置为输出

//初始化IIC
void IIC_Init(void)
{					     
	CLOCK_EnableClock(kCLOCK_Gpio0);//开启GPIO0时钟
	
//	gpio_pin_config_t config={kGPIO_DigitalOutput,0}; 
	GPIO_PinInit(GPIO,BOARD_INITPINS_GPIO_SCL_PORT,BOARD_INITPINS_GPIO_SCL_GPIO_PIN,&config);//SCL
	GPIO_PinInit(GPIO,BOARD_INITPINS_GPIO_SDA_PORT,BOARD_INITPINS_GPIO_SDA_GPIO_PIN,&config);//SDA首先配置为输出
 
	SET_IIC_SCL();//拉高电平
	SET_IIC_SDA();
}
//产生IIC起始信号
void IIC_Start(void)
{
	SDA_OUT();     //sda线输出
	SET_IIC_SDA();	  	  
	SET_IIC_SCL();
	Delay_us(4);
 	CLR_IIC_SDA();//START:when CLK is high,DATA change form high to low 
	Delay_us(4);
	CLR_IIC_SCL();//钳住I2C总线，准备发送或接收数据 
}	  
//产生IIC停止信号
void IIC_Stop(void)
{
	SDA_OUT();//sda线输出
	CLR_IIC_SCL();
	CLR_IIC_SDA();//STOP:when CLK is high DATA change form low to high
 	Delay_us(4);
	SET_IIC_SCL(); 
	SET_IIC_SDA();//发送I2C总线结束信号
	Delay_us(4);							   	
}
//等待应答信号到来
//返回值：1，接收应答失败
//        0，接收应答成功
u8 IIC_Wait_Ack(void)
{
	u8 ucErrTime=0;
	SDA_IN();      //SDA设置为输入  
	SET_IIC_SDA();Delay_us(1);	   
	SET_IIC_SCL();Delay_us(1);	 
	while(READ_SDA)
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			IIC_Stop();
			return 1;
		}
	}
	CLR_IIC_SCL();//时钟输出0 	   
	return 0;  
} 
//产生ACK应答
void IIC_Ack(void)
{
	CLR_IIC_SCL();
	SDA_OUT();
	CLR_IIC_SDA();
	Delay_us(2);
	SET_IIC_SCL();
	Delay_us(2);
	CLR_IIC_SCL();
}
//不产生ACK应答		    
void IIC_NAck(void)
{
	CLR_IIC_SCL();
	SDA_OUT();
	SET_IIC_SDA();
	Delay_us(2);
	SET_IIC_SCL();
	Delay_us(2);
	CLR_IIC_SCL();
}					 				     
//IIC发送一个字节
//返回从机有无应答
//1，有应答
//0，无应答			  
void IIC_Send_Byte(u8 txd)
{                        
    u8 t;   
	SDA_OUT(); 	    
    CLR_IIC_SCL();//拉低时钟开始数据传输
    for(t=0;t<8;t++)
    {              
//        IIC_SDA=(txd&0x80)>>7;由下面的if-else代替
		if((txd&0x80)>>7)
			SET_IIC_SDA();
		else
			CLR_IIC_SDA();
        txd<<=1; 	  
		Delay_us(2);   //对TEA5767这三个延时都是必须的
		SET_IIC_SCL();
		Delay_us(2); 
		CLR_IIC_SCL();	
		Delay_us(2);
    }	 
} 	    
//读1个字节，ack=1时，发送ACK，ack=0，发送nACK   
u8 IIC_Read_Byte(unsigned char ack)
{
	unsigned char i,receive=0;
	SDA_IN();//SDA设置为输入
    for(i=0;i<8;i++ )
	{
        CLR_IIC_SCL(); 
        Delay_us(2);
		SET_IIC_SCL();
        receive<<=1;
        if(READ_SDA)receive++;   
		Delay_us(1); 
    }					 
    if (!ack)
        IIC_NAck();//发送nACK
    else
        IIC_Ack(); //发送ACK   
    return receive;
}

/*********************PCF8591写数据函数************************************/ 
void PCF8591_WrDat(unsigned char c)
{
	IIC_Start();
	IIC_Send_Byte(0x90);
	IIC_Wait_Ack();
	IIC_Send_Byte(c);
	IIC_Wait_Ack();
	IIC_Stop();
}

unsigned char PCF8591_ReDat(void)
{
	unsigned char data;
	
	IIC_Start();
	IIC_Send_Byte(0x90+1);
	IIC_Wait_Ack();
	data = IIC_Read_Byte(1);
	IIC_Wait_Ack();
	IIC_Stop();
	
	return data;
}



