#ifndef __KEY_H__
#define __KEY_H__

#include "board.h"

/* This is SW1.  Press this to blink just the RED LED. */
#define BLINK_SWITCH_PORT   0
#define BLINK_SWITCH_BIT    1
/* This is SW2.  Press this to cycle through all LEDs.. */
#define CYCLE_SWITCH_PORT   0
#define CYCLE_SWITCH_BIT    16

//初始化宏定义
#define KEY_SW1_Init()	Chip_GPIO_SetPinDIRInput(LPC_GPIO, BLINK_SWITCH_PORT, BLINK_SWITCH_BIT)
#define KEY_SW21_Init()	Chip_GPIO_SetPinDIRInput(LPC_GPIO, CYCLE_SWITCH_PORT, CYCLE_SWITCH_BIT)

extern unsigned char Get_SW1_State(void);
extern unsigned char Get_SW2_State(void);

#endif
