#include "rgb_led.h"

int watch_rgb_led_timer = 0;
unsigned char watch_cnt = 0;
void RGB_LED_Blind(unsigned int timer)
{
	static unsigned int rgb_led_timer = 0u;
	static unsigned char cnt = 0u;
	
	rgb_led_timer ++;
	watch_rgb_led_timer = (int)rgb_led_timer;
	if(rgb_led_timer > timer)
	{
		rgb_led_timer = 0u;
		
		switch(cnt)
		{
			case 2u:
				LED_Red_On();
				LED_Green_Off();
				LED_Blue_Off();
				break;
			case 1u:
				LED_Red_Off();
				LED_Green_On();
				LED_Blue_Off();	
				break;
			case 0u:
				LED_Red_Off();
				LED_Green_Off();
				LED_Blue_On();
				break;
			default:
				break;
		}
	}
		
	cnt++;
	cnt = cnt>2?cnt=0:cnt;
	
	watch_cnt = (unsigned char)cnt;
}


