#ifndef __RGB_LED_H__
#define __RGB_LED_H__

#include "board.h"
//Board_Init()函数里面已经有了LED的初始化函数了
//这里对每个LED的调用做封装，方便调用
#define LED_Red_On()		Board_LED_Set(0, true);	
#define LED_Red_Off()		Board_LED_Set(0, false);
#define LED_Green_On()		Board_LED_Set(1, true);		
#define LED_Green_Off()		Board_LED_Set(1, false);		
#define LED_Blue_On()		Board_LED_Set(2, true);	
#define LED_Blue_Off()		Board_LED_Set(2, false);

extern void RGB_LED_Blind(unsigned int timer);


#endif
