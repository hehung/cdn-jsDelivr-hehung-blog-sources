#include "myOS.h"
#include "uart.h"
#include "chip.h"
#include "string.h"
#include "key.h"
#include "rgb_led.h"

/**
 * @brief    Handle interrupt from SysTick timer
 * @return    Nothing
 */
 
static void Task_Uart(void);

unsigned long long int system_run_time = 0;

void SysTick_Handler(void)
{
	static uint8_t timer_2ms = 0u;
	static uint8_t timer_50ms = 0u;
	static uint8_t timer_500ms = 0u;
	static uint8_t timer_1s = 0u;
	
	timer_2ms ++;
	if(timer_2ms >= 2u)
	{
		Timer_Task_2ms();
		timer_2ms = 0u;
		timer_50ms ++;
	}
	
	if(timer_50ms >= 25u)
	{
		Timer_Task_50ms();
		timer_50ms = 0u;
		timer_500ms ++;
	}
	
	if(timer_500ms >= 10u)
	{
		Timer_Task_500ms();
		timer_500ms = 0u;
		timer_1s ++;
	}
	
	if(timer_1s >= 2u)
	{
		Timer_Task_1s();
		timer_1s = 0u;
	}
	
	
	
}

//2ms任务
void Timer_Task_2ms(void)
{
	
	
	Task_Uart();	//串口处理函数
}

//50ms任务
void Timer_Task_50ms(void)
{
	system_run_time += 50u;
}

//500ms任务
void Timer_Task_500ms(void)
{
	
}

//1s任务
void Timer_Task_1s(void)
{
	
}

extern RINGBUFF_T txring, rxring;

uint8_t character = 0u;
int bytes;
static void Task_Uart(void)
{
		
	uint8_t cnt = 0u;
	
	//将串口接收的数据重新发送到串口
	bytes = Chip_UARTN_ReadRB(LPC_USART, &rxring, &character, 1);
	
	if (bytes > 0) {
		cnt = character;
		Chip_UARTN_SendRB(LPC_USART, &txring, (const uint8_t *)&character, 1);	
		bytes = 0;
	}
	
//	switch(cnt)
//	{
//		case 0u:LED_Red_Off();LED_Green_Off();LED_Blue_Off();break;
//		case 1u:LED_Red_Off();LED_Green_On();LED_Blue_Off();break;
//		case 2u:LED_Red_Off();LED_Green_Off();LED_Blue_On();break;
//		case 3u:LED_Red_On();LED_Green_Off();LED_Blue_Off();break;
//		case 4u:RGB_LED_Blind(300u);break;
//	}
}
