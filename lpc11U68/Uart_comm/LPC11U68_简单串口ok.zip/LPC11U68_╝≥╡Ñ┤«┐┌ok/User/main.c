#include "board.h"
#include <stdio.h>
#include "delay.h"
#include "uart.h"
#include "myOS.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

#define TICKRATE_HZ1 (1000)	/* 1000 ticks per second */

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/**
 * @brief    main routine for blinky example
 * @return    Function should not exit.
 */
int main(void)
{
	int dat;
	
	SystemCoreClockUpdate();
	Board_Init();
	/* Enable and setup SysTick Timer at a periodic rate */
	SysTick_Config(SystemCoreClock / TICKRATE_HZ1);
	/* Enable the RTC oscillator, oscillator rate can be determined by
	   calling Chip_Clock_GetRTCOscRate()    */
	Chip_Clock_EnableRTCOsc();
	Uart_Init();
	while (1) {
		Delay_ms(1u);
		
//		dat = Board_UARTGetChar();
//		if(dat != -1)   //接收到数据
//		{
//			Board_UARTPutChar(dat);  //USB串口发送
//		}
		
		__WFI();
	}

	return 0;
}


